# My Composition Book — APK (Android)

Este pacote gera o **APK** do app sem você instalar nada no computador.
O APK é montado na nuvem do GitHub (grátis) e você baixa o arquivo pronto.

## Passo a passo (uns 15 minutos)

1. Crie uma conta grátis em **github.com** (se ainda não tiver).
2. Clique em **New repository**, dê um nome (ex.: `composition-book`) e crie.
3. Na página do repositório, clique em **uploading an existing file** e arraste **todo o conteúdo desta pasta**
   (inclusive a pasta oculta `.github`). Se o seu aparelho não mostra pastas ocultas, use o computador:
   descompacte o zip e arraste tudo de uma vez. Clique em **Commit changes**.
4. Abra a aba **Actions**. Se pedir, clique em **I understand my workflows, enable them**.
5. Clique em **Gerar APK** → **Run workflow** → **Run workflow**.
6. Espere uns 6 a 12 minutos até aparecer um ✓ verde. Se aparecer ✗ vermelho, abra a execução, copie o texto do passo que falhou e me mande.
7. Dentro da execução, em **Artifacts**, baixe **My-Composition-Book-apk**. É um zip com o `app-debug.apk`.
8. No celular, abra o `.apk`. O Android vai pedir para permitir a instalação de **fontes desconhecidas** só para o app que você usou para abrir o arquivo (navegador ou gerenciador de arquivos). Aceite e instale.

## Observações
- É um APK de teste (assinatura "debug"). Funciona para instalar no seu celular e de amigos. **Para a Play Store** é preciso um pacote assinado com a sua chave: me avise e eu preparo.
- Tudo fica guardado **no aparelho** (não depende do Claude nem de conta). Use o backup completo (Configurações) para levar para outro aparelho.
- O microfone é pedido na primeira gravação. Voz para texto depende do Google no celular e de internet.
- Para atualizar o app depois: troque o arquivo `www/index.html` no repositório e rode **Gerar APK** de novo.
- Fontes: o passo "Fontes locais" baixa as fontes para dentro do app. Se ele falhar, o app ainda funciona, mas as fontes bonitas só aparecem com internet.

## Plano B (Android Studio)
Instale Node 20 e Android Studio, e na pasta do projeto rode:
`npm install`, `npx cap add android`, `python3 scripts/patch_android.py`, `npx cap sync android` e abra a pasta `android` no Android Studio.
