#!/usr/bin/env python3
"""Baixa as fontes do Google Fonts para dentro do app (assim ele funciona offline).
Se algo falhar, o app continua com o link da internet — não derruba o build."""
import re, sys, pathlib, urllib.request
www = pathlib.Path('www'); html_path = www / 'index.html'
html = html_path.read_text(encoding='utf-8')
m = re.search(r'<link[^>]+href="(https://fonts\.googleapis\.com/css2[^"]+)"[^>]*>', html)
if not m:
    print('link de fontes não encontrado — nada a fazer'); sys.exit(0)
UA = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36'
def get(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=40) as r: return r.read()
css = get(m.group(1).replace('&amp;', '&')).decode('utf-8')
fonts = www / 'fonts'; fonts.mkdir(exist_ok=True)
seen = {}
def fetch(mo):
    url = mo.group(1)
    if url not in seen:
        name = 'f%03d.woff2' % len(seen)
        (fonts / name).write_bytes(get(url)); seen[url] = name
    return 'url(fonts/%s)' % seen[url]
css = re.sub(r'url\((https://fonts\.gstatic\.com/[^)]+)\)', fetch, css)
html = html.replace(m.group(0), '<style>\n' + css + '\n</style>')
html_path.write_text(html, encoding='utf-8')
print('fontes locais:', len(seen), 'arquivos')
