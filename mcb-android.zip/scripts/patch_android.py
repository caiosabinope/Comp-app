#!/usr/bin/env python3
"""Ajusta o projeto Android gerado pelo Capacitor: microfone, vibração, retrato e versão."""
import re, pathlib, sys
root = pathlib.Path('android/app')
man = root / 'src/main/AndroidManifest.xml'
s = man.read_text(encoding='utf-8')

perms = [
    'android.permission.RECORD_AUDIO',
    'android.permission.MODIFY_AUDIO_SETTINGS',
    'android.permission.VIBRATE',
]
add = ''.join('    <uses-permission android:name="%s" />\n' % p for p in perms if p not in s)
if add:
    s = s.replace('</manifest>', add + '</manifest>')

# só em pé (retrato) e sem recriar a tela ao girar/trocar teclado
if 'android:screenOrientation' not in s:
    s = re.sub(r'(<activity\b)', r'\1 android:screenOrientation="portrait"', s, count=1)
man.write_text(s, encoding='utf-8')

# nome e versão
g = root / 'build.gradle'
t = g.read_text(encoding='utf-8')
t = re.sub(r'versionCode\s+\d+', 'versionCode 1', t)
t = re.sub(r'versionName\s+"[^"]*"', 'versionName "1.0"', t)
g.write_text(t, encoding='utf-8')
print('AndroidManifest e build.gradle ajustados')
